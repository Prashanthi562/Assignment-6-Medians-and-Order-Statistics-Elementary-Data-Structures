## Description:A deterministic algorithm that is used to locate the kth smallest element by splitting the array into blocks of five and calculating the median of these blocks, and recursively choosing the median of medians as a pivot. The efficiency of performance is guaranteed by dividing the array with this pivot and reducing the search to that fragment, which consequently leads to worst-case linear time.

def deterministic_select(arr, k):
    # Handling small arrays by directly sorting and selecting
    if len(arr) <= 5:
        return sorted(arr)[k - 1]

    # Dividing the array into chunks of five elements
    chunks = [arr[i:i + 5] for i in range(0, len(arr), 5)]
    
    # Finding the median of each chunk
    medians = [sorted(chunk)[len(chunk) // 2] for chunk in chunks]

    # Finding the pivot by recursively selecting the median of medians
    pivot = deterministic_select(medians, len(medians) // 2 + 1)

    # Splitting the array into elements less than pivot
    lows = [x for x in arr if x < pivot]
    
    # Splitting the array into elements greater than pivot
    highs = [x for x in arr if x > pivot]
    
    # Gathering all elements equal to pivot
    pivots = [x for x in arr if x == pivot]

    # Recursing on the left part if k is within lows
    if k <= len(lows):
        return deterministic_select(lows, k)
    
    # Returning pivot if k falls within the range of pivots
    elif k <= len(lows) + len(pivots):
        return pivot
    
    # Recursing on the right part if k is within highs
    else:
        return deterministic_select(highs, k - len(lows) - len(pivots))

# Checking if the script is being run directly
if __name__ == "__main__":
    # Defining a sample array of numbers
    arr = [12, 3, 5, 7, 4, 19, 26]

    # Setting the value of k to find the kth smallest element
    k = 3

    # Printing the result using the deterministic selection method
    print("Using deterministic select:")
    print(deterministic_select(arr, k))  
