## Description:Illustrating a first-in first-out structure in which items are placed on the back and rescued off the front. Testing involves peeking the front item and testing of emptiness.
    
# Creating a class to represent a queue structure
class Queue:
    # Initializing an empty list to store queue elements
    def __init__(self):
        self.data = []

    # Adding a value to the end of the queue
    def enqueue(self, value):
        self.data.append(value)

    # Removing and returning the front value if the queue is not empty
    def dequeue(self):
        if not self.is_empty():
            return self.data.pop(0)
        return None

    # Returning the front value without removing it if the queue is not empty
    def peek(self):
        if not self.is_empty():
            return self.data[0]
        return None

    # Checking if the queue has no elements
    def is_empty(self):
        return len(self.data) == 0

# Running test for queue
if __name__ == "__main__":
    print("\nTesting Queue:")
    queue = Queue()
    queue.enqueue(1)  # Adding first item to the end
    queue.enqueue(2)  # Adding second item to the end
    print("Peek:", queue.peek())  # Showing first item
    print("Dequeue:", queue.dequeue())  # Removing first item
    print("Dequeue:", queue.dequeue())  # Removing next item
    print("Is empty:", queue.is_empty())  # Checking if queue is empty
