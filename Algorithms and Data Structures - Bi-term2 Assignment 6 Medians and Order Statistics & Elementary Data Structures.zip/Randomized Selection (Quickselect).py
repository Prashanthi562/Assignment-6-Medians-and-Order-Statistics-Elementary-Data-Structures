## Description:The use of randomized pivoting algorithm to determine the kth smallest element, i.e., selecting an arbitrary pivot, combining the array to end up in three buckets of elements, and recursively reducing the search space. Ability to achieve expected linear time performance because of balanced splits in average cases.

import random

def randomized_select(arr, k):
    # Handling base case when the array has only one element
    if len(arr) == 1:
        return arr[0]

    # Choosing a random pivot from the array
    pivot = random.choice(arr)

    # Collecting all elements less than pivot
    lows = [x for x in arr if x < pivot]
    
    # Collecting all elements greater than pivot
    highs = [x for x in arr if x > pivot]
    
    # Collecting all elements equal to pivot
    pivots = [x for x in arr if x == pivot]

    # Recursing on the left part if k is within lows
    if k <= len(lows):
        return randomized_select(lows, k)
    
    # Returning pivot if k falls within the range of pivots
    elif k <= len(lows) + len(pivots):
        return pivot
    
    # Recursing on the right part if k is within highs
    else:
        return randomized_select(highs, k - len(lows) - len(pivots))

# Checking if the script is being run directly
if __name__ == "__main__":
    # Defining a sample array of numbers
    arr = [12, 3, 5, 7, 4, 19, 26]

    # Setting the value of k to find the kth smallest element
    k = 3

    # Printing the result using the randomized selection method
    print("Using randomized select:")
    print(randomized_select(arr, k)) 
