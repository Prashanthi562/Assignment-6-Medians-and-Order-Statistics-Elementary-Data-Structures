## Descripition:Illustrating storing retrieval, and deleting of values on the linear list and a two-dimensional matrix. Testing involves entry of values, position access and clear specified entries.
    
# Creating a class for storing and managing a simple list of values
class Array:
    # Initializing an empty list to hold the data
    def __init__(self):
        self.data = []

    # Adding a value to the end of the list
    def insert(self, value):
        self.data.append(value)

    # Removing the element at a specific position if the position is valid
    def delete(self, index):
        if 0 <= index < len(self.data):
            self.data.pop(index)

    # Returning the value at a specific position if the position is valid
    def access(self, index):
        if 0 <= index < len(self.data):
            return self.data[index]
        return None


# Creating a class to represent a grid of rows and columns
class Matrix:
    # Initializing the grid with default values
    def __init__(self, rows, cols):
        self.data = [[0 for _ in range(cols)] for _ in range(rows)]

    # Storing a value at a specific row and column position
    def insert(self, row, col, value):
        self.data[row][col] = value

    # Returning the value from a specific row and column
    def access(self, row, col):
        return self.data[row][col]

    # Resetting the value at a specific position to the default
    def delete(self, row, col):
        self.data[row][col] = 0  # or use None

# Running test for array and matrix
if __name__ == "__main__":
    # Creating and testing array
    print("Testing Array:")
    arr = Array()
    arr.insert(10)  # Adding first element
    arr.insert(20)  # Adding second element
    arr.insert(30)  # Adding third element
    print("Access index 1:", arr.access(1))
    arr.delete(1)  # Removing element at position 1
    print("Access index 1 after delete:", arr.access(1))  # Showing updated value

    # Creating and testing matrix
    print("\nTesting Matrix:")
    mat = Matrix(3, 3)  # Creating a grid with 3 rows and 3 columns
    mat.insert(1, 1, 5)  # Storing a value in the center cell
    print("Access (1, 1):", mat.access(1, 1))  # Showing stored value
    mat.delete(1, 1)  # Clearing the value at that cell
    print("Access (1, 1) after delete:", mat.access(1, 1))  # Showing cleared value
