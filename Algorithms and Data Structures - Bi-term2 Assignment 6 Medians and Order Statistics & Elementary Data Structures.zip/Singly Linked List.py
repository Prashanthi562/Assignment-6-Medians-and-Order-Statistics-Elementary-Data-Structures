## Description:Creating a graph of interlocked nodes and dynamic insertions and deletions. Traversing shows the before and after of a structure when a value is selected.
    
# Creating a class to represent a single node in the list
class Node:
    # Storing the value and link to the next node
    def __init__(self, value):
        self.value = value
        self.next = None

# Creating a class to manage a singly linked list
class LinkedList:
    # Initializing the list with no starting node
    def __init__(self):
        self.head = None

    # Adding a new value at the beginning of the list
    def insert_at_head(self, value):
        new_node = Node(value)
        new_node.next = self.head
        self.head = new_node

    # Adding a new value at the end of the list
    def insert_at_tail(self, value):
        new_node = Node(value)
        if not self.head:
            self.head = new_node
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = new_node

    # Removing the first node that contains the specified value
    def delete_by_value(self, value):
        if not self.head:
            return
        if self.head.value == value:
            self.head = self.head.next
            return
        current = self.head
        while current.next and current.next.value != value:
            current = current.next
        if current.next:
            current.next = current.next.next

    # Moving through the list and printing each value
    def traverse(self):
        current = self.head
        while current:
            print(current.value, end=" -> ")
            current = current.next
        print("None")

# Running test for linked list
if __name__ == "__main__":
    print("\nTesting LinkedList:")
    ll = LinkedList()
    ll.insert_at_head(5)  # Adding element at the beginning
    ll.insert_at_tail(10)  # Adding element at the end
    ll.insert_at_head(3)  # Adding another element at the beginning
    ll.traverse()  # Showing all elements in order
    ll.delete_by_value(5)  # Removing the element with specific value
    ll.traverse()  # Showing updated list
