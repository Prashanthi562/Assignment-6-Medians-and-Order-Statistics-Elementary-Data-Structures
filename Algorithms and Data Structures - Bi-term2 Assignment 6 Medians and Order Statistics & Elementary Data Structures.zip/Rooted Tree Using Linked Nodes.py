## Description:Producing a rooted tree of levels containing children. Showing the whole tree with the indentation to indicate the relationship between the nodes.
    
# Creating a class to represent a node in a tree structure
class TreeNode:
    # Storing the value and initializing an empty list for child nodes
    def __init__(self, value):
        self.value = value
        self.children = []

    # Adding a child node to the current node
    def add_child(self, node):
        self.children.append(node)

    # Visiting the current node and then recursively visiting its children
    def traverse(self, level=0):
        print("  " * level + str(self.value))
        for child in self.children:
            child.traverse(level + 1)

# Running test for tree node structure
if __name__ == "__main__":
    print("\nTesting TreeNode:")
    root = TreeNode("A")  # Creating the root node
    child1 = TreeNode("B")  # Creating a child node
    child2 = TreeNode("C")  # Creating another child node
    root.add_child(child1)  # Attaching first child
    root.add_child(child2)  # Attaching second child
    child1.add_child(TreeNode("D"))  # Attaching a grandchild
    child1.add_child(TreeNode("E"))  # Attaching another grandchild
    root.traverse()  # Displaying the full tree structure
