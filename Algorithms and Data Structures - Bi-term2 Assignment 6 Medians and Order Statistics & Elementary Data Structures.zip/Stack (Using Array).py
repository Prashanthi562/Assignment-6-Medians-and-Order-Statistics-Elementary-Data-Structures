## Description:By performing a simulation of a last-in-first-out structure by inserting and deleting elements at the top. Tests involve verifying the highest value, and confirming off when taken out.
    
# Creating a class to represent a stack structure
class Stack:
    # Initializing an empty list to store stack elements
    def __init__(self):
        self.data = []

    # Adding a value to the top of the stack
    def push(self, value):
        self.data.append(value)

    # Removing and returning the top value if the stack is not empty
    def pop(self):
        if not self.is_empty():
            return self.data.pop()
        return None

    # Returning the top value without removing it if the stack is not empty
    def peek(self):
        if not self.is_empty():
            return self.data[-1]
        return None

    # Checking if the stack has no elements
    def is_empty(self):
        return len(self.data) == 0

# Running test for stack
if __name__ == "__main__":
    print("\nTesting Stack:")
    stack = Stack()
    stack.push(100)  # Adding first item
    stack.push(200)  # Adding second item
    print("Peek:", stack.peek())  # Showing top item
    print("Pop:", stack.pop())  # Removing top item
    print("Pop:", stack.pop())  # Removing next item
    print("Is empty:", stack.is_empty())  # Checking if stack is empty
